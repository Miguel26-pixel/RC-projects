#ifndef PROJ_SRC_DATA_LINK_LAYER_INCLUDE_ALARM_H_
#define PROJ_SRC_DATA_LINK_LAYER_INCLUDE_ALARM_H_

int setup_alarm(void);
void sigalrm_handler(__attribute__((unused)) int _);

#endif  // PROJ_SRC_DATA_LINK_LAYER_INCLUDE_ALARM_H_
