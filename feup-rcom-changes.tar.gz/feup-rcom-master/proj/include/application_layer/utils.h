#ifndef PROJ_SRC_APPLICATION_LAYER_INCLUDE_UTILS_H_
#define PROJ_SRC_APPLICATION_LAYER_INCLUDE_UTILS_H_

#include <stddef.h>

size_t get_file_size(char *file_path);

#endif //PROJ_SRC_APPLICATION_LAYER_INCLUDE_UTILS_H_
